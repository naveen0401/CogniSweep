# ErrorSweep v44 — Self-hosted MT Router, NLLB Removed, Media Editor Fix

This upgrade removes the built-in Azure route and removes NLLB completely from the active app path.

## App no-key translation route

```text
User has BYO API key
→ existing BYO key path

User has no key + target/source is Indian language
→ self-hosted IndicTrans2 endpoint

User has no key + global language pair
→ self-hosted OPUS-MT endpoint

No endpoint available
→ clear setup error and route rows to review/manual editing
```

## Files to replace/add in GitHub root

Replace:

```text
app_errorsweep_platform_v44_self_hosted_mt_media_fix.py → app.py
requirements_errorsweep_platform_v44.txt → requirements.txt
translator_router.py
```

Add:

```text
selfhosted_mt_clients.py
indictrans2_client.py
opus_mt_client.py
```

Optional server files, for the self-hosted MT machine, not Streamlit Cloud:

```text
indictrans2_server.py
opus_mt_server.py
requirements_self_hosted_mt_server.txt
Dockerfile.selfhosted-mt
docker-compose.selfhosted-mt.yml
```

Remove from GitHub if present:

```text
nllb_translator.py
azure_translator.py
requirements_errorsweep_nllb_optional.txt
```

## Streamlit secrets

Remove or blank:

```toml
NLLB_MODE = ""
NLLB_MODEL_NAME = ""
AZURE_TRANSLATOR_KEY = ""
AZURE_TRANSLATOR_REGION = ""
AZURE_TRANSLATOR_ENDPOINT = ""
```

Add:

```toml
INDICTRANS2_ENDPOINT = "https://indic.yourdomain.com/translate"
INDICTRANS2_API_KEY = "your-private-indictrans2-token"

OPUS_MT_ENDPOINT = "https://opus.yourdomain.com/translate"
OPUS_MT_API_KEY = "your-private-opus-token"

SELF_HOSTED_MT_TIMEOUT = "180"
SELF_HOSTED_MT_DISABLE_INDIC = "false"
SELF_HOSTED_MT_DISABLE_OPUS = "false"
```

## Media editor fix

The Subtitle / Transcription setup now creates a media editor job and shows an external editor link:

```text
Open Transcription Editor ↗
Open Subtitle Editor ↗
```

This mirrors the Pro translation editor behavior.

## Push commands

```bash
cd /workspaces/Error-Sweep

cp app_errorsweep_platform_v44_self_hosted_mt_media_fix.py app.py
cp requirements_errorsweep_platform_v44.txt requirements.txt
cp translator_router_v44_self_hosted.py translator_router.py

python -m py_compile app.py translator_router.py selfhosted_mt_clients.py indictrans2_client.py opus_mt_client.py editor_job_store.py production_persistence.py speech_transcription.py

git add app.py requirements.txt translator_router.py selfhosted_mt_clients.py indictrans2_client.py opus_mt_client.py

git rm --ignore-unmatch nllb_translator.py azure_translator.py requirements_errorsweep_nllb_optional.txt

git commit -m "Switch built-in MT to self-hosted IndicTrans2 OPUS-MT and remove NLLB v44"
git push origin main
```

Then reboot Streamlit.

## Test

1. Confirm Pro translation with Telugu asks for IndicTrans2 endpoint if not configured.
2. Configure INDICTRANS2_ENDPOINT.
3. Run Pro Telugu translation.
4. Open Subtitle / Transcription Editor.
5. Upload video/audio.
6. Click Create transcription workspace.
7. Click Open Transcription Editor ↗.

The external media editor should open with blank rows if there is no BYO API key, or transcript rows if the user has BYO speech-to-text key.
