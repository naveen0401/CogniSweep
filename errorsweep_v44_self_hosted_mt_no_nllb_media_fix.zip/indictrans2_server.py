"""IndicTrans2 FastAPI server for ErrorSweep v44. Run on your own GPU server."""
from __future__ import annotations
import os
from functools import lru_cache
from typing import List, Optional
import torch
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

try:
    from IndicTransToolkit.processor import IndicProcessor
except Exception:
    try:
        from IndicTransToolkit import IndicProcessor
    except Exception:
        IndicProcessor = None

API_KEY = os.environ.get("INDICTRANS2_API_KEY", "")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
EN_INDIC_MODEL = os.environ.get("INDICTRANS2_EN_INDIC_MODEL", "ai4bharat/indictrans2-en-indic-dist-200M")
INDIC_EN_MODEL = os.environ.get("INDICTRANS2_INDIC_EN_MODEL", "ai4bharat/indictrans2-indic-en-dist-200M")
INDIC_INDIC_MODEL = os.environ.get("INDICTRANS2_INDIC_INDIC_MODEL", "ai4bharat/indictrans2-indic-indic-dist-320M")
INDIC_LANGS = {"asm_Beng","ben_Beng","brx_Deva","doi_Deva","gom_Deva","guj_Gujr","hin_Deva","kan_Knda","kas_Arab","kas_Deva","mai_Deva","mal_Mlym","mar_Deva","mni_Beng","mni_Mtei","npi_Deva","ory_Orya","pan_Guru","san_Deva","sat_Olck","snd_Arab","snd_Deva","tam_Taml","tel_Telu","urd_Arab"}
app = FastAPI(title="ErrorSweep IndicTrans2 Server", version="v44")

class TranslateRequest(BaseModel):
    source_language: str = "eng_Latn"
    target_language: str
    texts: List[str]

class TranslateResponse(BaseModel):
    translations: List[str]
    engine: str
    model: str

def require_auth(authorization: Optional[str]) -> None:
    if not API_KEY:
        return
    if authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="Unauthorized")

def choose_model(src: str, tgt: str) -> str:
    if src == "eng_Latn" and tgt in INDIC_LANGS:
        return EN_INDIC_MODEL
    if src in INDIC_LANGS and tgt == "eng_Latn":
        return INDIC_EN_MODEL
    if src in INDIC_LANGS and tgt in INDIC_LANGS:
        return INDIC_INDIC_MODEL
    raise HTTPException(status_code=400, detail=f"Unsupported IndicTrans2 pair: {src}->{tgt}")

@lru_cache(maxsize=3)
def load_model(model_name: str):
    if IndicProcessor is None:
        raise RuntimeError("IndicTransToolkit is not installed. Run: pip install indictranstoolkit")
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    dtype = torch.float16 if DEVICE == "cuda" else torch.float32
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name, trust_remote_code=True, torch_dtype=dtype).to(DEVICE)
    model.eval()
    processor = IndicProcessor(inference=True)
    return tokenizer, model, processor

@app.get("/health")
def health():
    return {"ok": True, "device": DEVICE}

@app.get("/models")
def models():
    return {"device": DEVICE, "en_indic": EN_INDIC_MODEL, "indic_en": INDIC_EN_MODEL, "indic_indic": INDIC_INDIC_MODEL}

@app.post("/translate", response_model=TranslateResponse)
def translate(req: TranslateRequest, authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    src=req.source_language.strip(); tgt=req.target_language.strip()
    model_name=choose_model(src,tgt)
    texts=[str(t or "") for t in req.texts]
    if not texts:
        return TranslateResponse(translations=[], engine="indictrans2", model=model_name)
    try:
        tokenizer, model, processor = load_model(model_name)
        batch = processor.preprocess_batch(texts, src_lang=src, tgt_lang=tgt)
        inputs = tokenizer(batch, truncation=True, padding="longest", return_tensors="pt", return_attention_mask=True).to(DEVICE)
        with torch.no_grad():
            generated = model.generate(**inputs, use_cache=True, min_length=0, max_length=256, num_beams=4, num_return_sequences=1)
        decoded = tokenizer.batch_decode(generated.detach().cpu().tolist(), skip_special_tokens=True, clean_up_tokenization_spaces=True)
        translations = processor.postprocess_batch(decoded, lang=tgt)
        return TranslateResponse(translations=translations, engine="indictrans2", model=model_name)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"IndicTrans2 translation failed: {exc}")
