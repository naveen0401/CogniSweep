"""OPUS-MT FastAPI server for ErrorSweep v44. Run on your own CPU/GPU server."""
from __future__ import annotations
import os
from functools import lru_cache
from typing import Dict, List, Optional
import torch
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from transformers import MarianMTModel, MarianTokenizer

API_KEY = os.environ.get("OPUS_MT_API_KEY", "")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DEFAULT_MODEL_MAP: Dict[str, str] = {
    "en-fr": "Helsinki-NLP/opus-mt-en-fr",
    "en-de": "Helsinki-NLP/opus-mt-en-de",
    "en-es": "Helsinki-NLP/opus-mt-en-es",
    "en-it": "Helsinki-NLP/opus-mt-en-it",
    "en-pt": "Helsinki-NLP/opus-mt-en-pt",
    "en-ru": "Helsinki-NLP/opus-mt-en-ru",
    "fr-en": "Helsinki-NLP/opus-mt-fr-en",
    "de-en": "Helsinki-NLP/opus-mt-de-en",
    "es-en": "Helsinki-NLP/opus-mt-es-en",
    "it-en": "Helsinki-NLP/opus-mt-it-en",
    "pt-en": "Helsinki-NLP/opus-mt-pt-en",
    "ru-en": "Helsinki-NLP/opus-mt-ru-en",
}
app = FastAPI(title="ErrorSweep OPUS-MT Server", version="v44")

class TranslateRequest(BaseModel):
    source_language: str = "en"
    target_language: str
    texts: List[str]

class TranslateResponse(BaseModel):
    translations: List[str]
    engine: str
    model: str

def require_auth(authorization: Optional[str]) -> None:
    if not API_KEY:
        return
    if authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="Unauthorized")

def model_name_for(src: str, tgt: str) -> str:
    pair=f"{src.strip().lower()}-{tgt.strip().lower()}"
    return DEFAULT_MODEL_MAP.get(pair, f"Helsinki-NLP/opus-mt-{pair}")

@lru_cache(maxsize=16)
def load_model(model_name: str):
    tokenizer=MarianTokenizer.from_pretrained(model_name)
    model=MarianMTModel.from_pretrained(model_name).to(DEVICE)
    model.eval()
    return tokenizer, model

@app.get("/health")
def health():
    return {"ok": True, "device": DEVICE}

@app.get("/models")
def models():
    return {"available_pairs": sorted(DEFAULT_MODEL_MAP.keys()), "device": DEVICE}

@app.post("/translate", response_model=TranslateResponse)
def translate(req: TranslateRequest, authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    src=req.source_language.strip().lower(); tgt=req.target_language.strip().lower()
    model_name=model_name_for(src,tgt)
    try:
        tokenizer, model = load_model(model_name)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not load OPUS-MT model for {src}->{tgt}: {model_name}. {exc}")
    texts=[str(t or "") for t in req.texts]
    if not texts:
        return TranslateResponse(translations=[], engine="opus_mt", model=model_name)
    batch=tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=256).to(DEVICE)
    with torch.no_grad():
        generated=model.generate(**batch, max_length=256, num_beams=4)
    translations=tokenizer.batch_decode(generated, skip_special_tokens=True)
    return TranslateResponse(translations=translations, engine="opus_mt", model=model_name)
